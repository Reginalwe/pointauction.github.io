export const chatBotToken = 'oauth:x5mb08s1lyszezcmqoquz0du10jxbk';
