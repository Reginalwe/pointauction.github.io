export const DOCUMENTATION_PARAGRAPHS = [
  {
    title: 'Мотивация создания аукциона',
    key: 'motivation',
  },
  {
    title: 'Основная фича аукциона',
    key: 'main-feature',
  },
  {
    title: 'Поинтовый аукцион',
    key: 'point-auc',
  },
  {
    title: 'Донатный аукцион',
    key: 'donate-auc',
  },
  {
    title: 'Шаровой аукцион',
    key: 'marbles-auc',
  },
  {
    title: 'Колесо',
    key: 'wheel',
  },
  {
    title: 'Статистика',
    key: 'statistic',
  },
  {
    title: 'История',
    key: 'history',
  },
  {
    title: 'Спонсоры',
    key: 'sponsors',
  },
  {
    title: 'Мои контакты',
    key: 'contacts',
  },
];
