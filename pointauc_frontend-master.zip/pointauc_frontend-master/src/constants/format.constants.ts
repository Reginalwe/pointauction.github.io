export const FORMAT = {
  DATE: {
    time: 'HH:mm:ss',
    dateTime: 'DD.MM HH:mm',
  },
};
