// eslint-disable-next-line import/prefer-default-export
export const DEFAULT_SLOT_NAME = 'Пустой слот';

export const AUTOSAVE_NAME = 'Автосохранение';
