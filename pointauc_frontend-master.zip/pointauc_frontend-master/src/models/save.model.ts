export interface SaveInfo {
  timestamp: string;
  name: string;
  length: string;
  slotsLocation: string;
}
