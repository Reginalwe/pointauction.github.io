export interface VideoSnippet {
  id: {
    videoId: string;
  };
  snippet: {
    title: string;
  };
}
