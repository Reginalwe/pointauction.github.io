export interface Trailer {
  id: number;
  title: string;
}
