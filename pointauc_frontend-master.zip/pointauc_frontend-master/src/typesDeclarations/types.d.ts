declare module '*.pdf' {
  const value: string;
  export default value;
}
