export enum InsertStrategy {
  Force = 'force',
  Match = 'match',
  None = 'none',
  Auto = 'auto',
}
