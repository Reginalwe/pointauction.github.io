// eslint-disable-next-line import/prefer-default-export
export enum DragTypeEnum {
  Purchase = 'purchase',
}
