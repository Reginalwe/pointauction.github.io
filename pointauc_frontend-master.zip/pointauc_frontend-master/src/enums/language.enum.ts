export enum Language {
  RU = 'ru',
  EN = 'en',
  BE = 'be',
  UA = 'ua',
}
