# Frontend for the [pointauc.com](https://pointauc.com)

This site helps streamers manage viewer requests for various types of auctions.

## Suggestions and bugreports

You can create an [issue](https://github.com/Pointauc/pointauc_frontend/issues) if you want to suggest something or tell about a bug.